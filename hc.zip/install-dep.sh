#!/bin/sh
npm update --save
exit